# Jafari Tours & Travels website

Upload these four files to the root of the existing GitHub repository `Jafari-Tours-App`:
- index.html
- jafari-logo.png
- manifest.json
- sw.js

Commit the changes to the `main` branch. GitHub Pages is already configured to publish from `main` / (root).

Website URL:
https://jafaritours2012.github.io/Jafari-Tours-App/

The booking form opens WhatsApp to +91 99306 07640. It does not store enquiry data or request passport numbers.
