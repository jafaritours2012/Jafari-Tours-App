JAFARI TOURS & TRAVELS — ANDROID STUDIO PROJECT

This is an Android Studio project wrapping the supplied Jafari Tours & Travels app in an Android WebView. The app content is bundled locally, so the main screens work offline. WhatsApp and phone links open the relevant installed apps.

BUILD AN APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio > Open > select the JafariToursAndroid folder.
4. Allow Gradle sync and install the Android SDK platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

APP DETAILS
- Application ID: com.jafari.tours
- App name: Jafari Tours
- Minimum Android: 6.0 (API 23)
- Contacts shown: Mohammed Reza (9930607640), Faiz Mohammed (82685 71786)
- Office: Alif Plaza, Opp. Swad Hotel, Shop No. 21, Kanodar (Gujarat), India

IMPORTANT
This is the editable Android Studio source project, not a precompiled APK. A local Android SDK/Gradle build is required to compile and sign the APK. Booking inquiries open WhatsApp; there is no payment processing or server-side booking dashboard in this first version. Confirm package rates, dates and hotel availability before publishing.
